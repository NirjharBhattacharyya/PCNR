library(testthat)
library(PCNR)

test_check('PCNR')
