# PCNR 0.1.1
- Adds analysis helpers (metrics, communities, compare, GraphML export)
- Fixes DESCRIPTION formatting and provides package-level imports
